$(function(){
    var a = $("a");
  a.each(function(){
    $(this).prop('href','#');
  });
  });
